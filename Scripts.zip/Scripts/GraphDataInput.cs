﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ChartAndGraph;
using UnityEngine.Networking;
using UnityEngine.UI;
using System;
using TMPro;
using UnityEngine.SceneManagement;

public class GraphDataInput : MonoBehaviour
{
    // Start is called before the first frame update
    public GraphChart chart;
    public CandleChart candle;

    public Dropdown XaxisDropdown;
    public Dropdown TrackDropdown;
    public Dropdown ColorDropdown;
    public Dropdown IdDropdown;
    public Toggle averages;
    public GameObject legend;
    public TMP_Text legendText;
    public TMP_Text xaxistext;

    public int dataSize;    // Number of rows in the data Table(number of games)
    public string[,] dataTable;

    public int avg1;
    public int avg2;
    public int avg3;
    public int avg4;
    public int avg5;
    public int avg6;
    public int avg7;
    public int avg8;
    public int avg9;
    public int count1;
    public int count2;
    public int count3;
    public int count4;
    public int count5;
    public int count6;
    public int count7;
    public int count8;
    public int count9;

    public int avgBayes;
    public int avgNight;
    public int avgGauss;
    public int countBayes;
    public int countNight;
    public int countGauss;

    bool updatedAvg = false;

    bool inFirst = false;
    bool inSecond = false;

    bool start = true;

    void Start()
    {
        StartCoroutine(GetSize());
        StartCoroutine(GetScores());
        chart.HorizontalValueToStringMap.Add(0, "");
        chart.HorizontalValueToStringMap.Add(1, "");
        chart.HorizontalValueToStringMap.Add(2, "Bayes");
        chart.HorizontalValueToStringMap.Add(3, "");
        chart.HorizontalValueToStringMap.Add(4, ""); // Empty
        chart.HorizontalValueToStringMap.Add(5, "");
        chart.HorizontalValueToStringMap.Add(6, "Nightingale");
        chart.HorizontalValueToStringMap.Add(7, "");
        chart.HorizontalValueToStringMap.Add(8, "");
        chart.HorizontalValueToStringMap.Add(9, "");
        chart.HorizontalValueToStringMap.Add(10, "Gauss");
        chart.HorizontalValueToStringMap.Add(11, "");

    }

    // Update is called once per frame
    void Update()
    {

        if(inFirst || inSecond)
        {
            XaxisDropdown.interactable = false;
            TrackDropdown.interactable = false;
            ColorDropdown.interactable = false;
            IdDropdown.interactable = false;

        }
        else
        {
            XaxisDropdown.interactable = true;
            TrackDropdown.interactable = true;
            ColorDropdown.interactable = true;
            IdDropdown.interactable = true;
        }

        if (start)
        {
            ChangeGraphByCarPart();
        }

    }

    public void ShowAvg()
    {
        if (averages.isOn)
        {
            updatedAvg = true;
            if (ColorDropdown.value == 0 || ColorDropdown.value == XaxisDropdown.value)
            {
                UpdateAvg();
            }
            else
            {
                UpdateAvg3Variable();
            }


        }
        else
        {
            chart.DataSource.ClearCategory("AvgBayes");
            chart.DataSource.ClearCategory("AvgNight");
            chart.DataSource.ClearCategory("AvgGauss");
        }
    }

    public void UpdateAvg()
    {
        if (updatedAvg && averages.isOn)
        {
            chart.DataSource.StartBatch();
            //chart.DataSource.ClearCategory("Bayes");
            //chart.DataSource.ClearCategory("Nightingale");
            //chart.DataSource.ClearCategory("Gauss");


            chart.DataSource.ClearCategory("AvgBayes");
            chart.DataSource.ClearCategory("AvgNight");
            chart.DataSource.ClearCategory("AvgGauss");
            if (avgBayes != 0 && countBayes != 0)
                chart.DataSource.AddPointToCategory("AvgBayes", 2, avgBayes / countBayes);
            if (avgNight != 0 && countNight != 0)
                chart.DataSource.AddPointToCategory("AvgNight", 6, avgNight / countNight);
            if (avgGauss != 0 && countGauss != 0)
                chart.DataSource.AddPointToCategory("AvgGauss", 10, avgGauss / countGauss);
            chart.DataSource.EndBatch();

            updatedAvg = false;
        }


    }

    public void UpdateAvg3Variable()
    {
        if (updatedAvg && averages.isOn)
        {
            chart.DataSource.StartBatch();
            chart.DataSource.ClearCategory("AvgBayes");
            chart.DataSource.ClearCategory("AvgNight");
            chart.DataSource.ClearCategory("AvgGauss");
            if (avg1 != 0 && count1 != 0)
                chart.DataSource.AddPointToCategory("AvgBayes", 1, avg1 / count1);
            if (avg2 != 0 && count2 != 0)
                chart.DataSource.AddPointToCategory("AvgNight", 2, avg2 / count2);
            if (avg3 != 0 && count3 != 0)
                chart.DataSource.AddPointToCategory("AvgGauss", 3, avg3 / count3);
            if (avg4 != 0 && count4 != 0)
                chart.DataSource.AddPointToCategory("AvgBayes", 5, avg4 / count4);
            if (avg5 != 0 && count5 != 0)
                chart.DataSource.AddPointToCategory("AvgNight", 6, avg5 / count5);
            if (avg6 != 0 && count6 != 0)
                chart.DataSource.AddPointToCategory("AvgGauss", 7, avg6 / count6);
            if (avg7 != 0 && count7 != 0)
                chart.DataSource.AddPointToCategory("AvgBayes", 9, avg7 / count7);
            if (avg8 != 0 && count8 != 0)
                chart.DataSource.AddPointToCategory("AvgNight", 10, avg8 / count8);
            if (avg9 != 0 && count9 != 0)
                chart.DataSource.AddPointToCategory("AvgGauss", 11, avg9 / count9);
            chart.DataSource.EndBatch();

            updatedAvg = false;
        }

    }

    public void ChangeGraphByCarPart()
    {
        int carPart = XaxisDropdown.value;
        int track = TrackDropdown.value;
        int id = IdDropdown.value;

        /*if (carPart == 0)
        {
            return;
        }*/
        carPart++;

        // Set X-axis text below the axis, at the bottom of the screen
        switch (carPart)
        {
            case 1:
                xaxistext.text = "Body";
                break;
            case 2:
                xaxistext.text = "Engine";
                break;
            case 3:
                xaxistext.text = "Tire";
                break;
        }

        string curTrack = TrackDropdown.captionText.text;
        
        carPart--;

        chart.DataSource.StartBatch();

        chart.DataSource.ClearCategory("Bayes");
        chart.DataSource.ClearCategory("Nightingale");
        chart.DataSource.ClearCategory("Gauss");
        avgBayes = 0;
        avgNight = 0;
        avgGauss = 0;
        countBayes = 0;
        countNight = 0;
        countGauss = 0;



        for (int i = 0; i < dataSize; i++)
        {
            // Remove values higher than 90 for now
            if (float.Parse(dataTable[i, 3]) < 150)
            {
                switch (id)
                {
                    /*case 0:
                        if (dataTable[i, 4].Equals(curTrack) || track == 0)
                        {
                            if (dataTable[i, carPart].Equals("Bayes"))
                            {
                                chart.DataSource.AddPointToCategory("Bayes", 2, float.Parse(dataTable[i, 3]));
                                avgBayes += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                countBayes++;
                                //candle.DataSource.AddCandleToCategory("Player 1", new CandleChartData.CandleValue(Random.Range(5f, 10f), Random.Range(10f, 15f), Random.Range(0f, 5f), Random.Range(5f, 10f), i * 10f / 30f, Random.value * 10f / 30f));
                            }
                            if (dataTable[i, carPart].Equals("Nightingale"))
                            {
                                chart.DataSource.AddPointToCategory("Nightingale", 6, float.Parse(dataTable[i, 3]));
                                avgNight += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                countNight++;
                            }
                            if (dataTable[i, carPart].Equals("Gauss"))
                            {
                                chart.DataSource.AddPointToCategory("Gauss", 10, float.Parse(dataTable[i, 3]));
                                avgGauss += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                countGauss++;
                            }
                        }

                        break;*/
                    case 0:
                        if (dataTable[i,5].ToLower().Equals(PlayerData.Instance.playerId.ToLower())
                            && dataTable[i, 6].ToLower().Equals(PlayerData.Instance.groupId.ToLower()))
                        {
                            if (dataTable[i, 4].Equals(curTrack) || track == 0)
                            {
                                if (dataTable[i, carPart].Equals("Bayes"))
                                {
                                    chart.DataSource.AddPointToCategory("Bayes", 2, float.Parse(dataTable[i, 3]));
                                    avgBayes += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    countBayes++;
                                    //candle.DataSource.AddCandleToCategory("Player 1", new CandleChartData.CandleValue(Random.Range(5f, 10f), Random.Range(10f, 15f), Random.Range(0f, 5f), Random.Range(5f, 10f), i * 10f / 30f, Random.value * 10f / 30f));
                                }
                                if (dataTable[i, carPart].Equals("Nightingale"))
                                {
                                    chart.DataSource.AddPointToCategory("Nightingale", 6, float.Parse(dataTable[i, 3]));
                                    avgNight += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    countNight++;
                                }
                                if (dataTable[i, carPart].Equals("Gauss"))
                                {
                                    chart.DataSource.AddPointToCategory("Gauss", 10, float.Parse(dataTable[i, 3]));
                                    avgGauss += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    countGauss++;
                                }
                            }
                        }
                        break;
                    case 1:
                        if (dataTable[i, 6].ToLower().Equals(PlayerData.Instance.groupId.ToLower()))
                        {
                            if (dataTable[i, 4].Equals(curTrack) || track == 0)
                            {
                                if (dataTable[i, carPart].Equals("Bayes"))
                                {
                                    chart.DataSource.AddPointToCategory("Bayes", 2, float.Parse(dataTable[i, 3]));
                                    avgBayes += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    countBayes++;
                                    //candle.DataSource.AddCandleToCategory("Player 1", new CandleChartData.CandleValue(Random.Range(5f, 10f), Random.Range(10f, 15f), Random.Range(0f, 5f), Random.Range(5f, 10f), i * 10f / 30f, Random.value * 10f / 30f));
                                }
                                if (dataTable[i, carPart].Equals("Nightingale"))
                                {
                                    chart.DataSource.AddPointToCategory("Nightingale", 6, float.Parse(dataTable[i, 3]));
                                    avgNight += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    countNight++;
                                }
                                if (dataTable[i, carPart].Equals("Gauss"))
                                {
                                    chart.DataSource.AddPointToCategory("Gauss", 10, float.Parse(dataTable[i, 3]));
                                    avgGauss += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    countGauss++;
                                }
                            }
                        }
                        break;
                }
            }
        }
        chart.DataSource.EndBatch();
        updatedAvg = true;
        UpdateAvg();

        //chart2.DataSource.EndBatch();
        //chart3.DataSource.EndBatch();

    }

    public void ChangeGraphWith3Variables()
    {
        int carPart = XaxisDropdown.value;
        int track = TrackDropdown.value;
        int color = ColorDropdown.value;
        int id = IdDropdown.value;

        start = false;

        if (color == 0 || color == carPart)
        {
            //if(carPart != 0)
            //{
                if(color == carPart && carPart != 0)
                {
                    legend.SetActive(true);
                    legendText.text = ColorDropdown.captionText.text;
                }
                else if(color == 0)
                {
                    legend.SetActive(false);
                }

                ChangeGraphByCarPart();
            //}
            return;
        }

        carPart++;
        legend.SetActive(true);
        legendText.text = ColorDropdown.captionText.text;


        switch (carPart)
        {
            case 1:
                xaxistext.text = "Body";
                break;
            case 2:
                xaxistext.text = "Engine";
                break;
            case 3:
                xaxistext.text = "Tire";
                break;
        }

        string curTrack = TrackDropdown.captionText.text;



        carPart--;
        color--;

        chart.DataSource.StartBatch();

        chart.DataSource.ClearCategory("Bayes");
        chart.DataSource.ClearCategory("Nightingale");
        chart.DataSource.ClearCategory("Gauss");
        avg1 = 0;
        avg2 = 0;
        avg3 = 0;
        avg4 = 0;
        avg5 = 0;
        avg6 = 0;
        avg7 = 0;
        avg8 = 0;
        avg9 = 0;
        count1 = 0;
        count2 = 0;
        count3 = 0;
        count4 = 0;
        count5 = 0;
        count6 = 0;
        count7 = 0;
        count8 = 0;
        count9 = 0;



        for (int i = 0; i < dataSize; i++)
        {
            // Remove values higher than 90 for now
            if (float.Parse(dataTable[i, 3]) < 150)
            {
                // Filter by track
                if (dataTable[i, 4].Equals(curTrack) || track == 0)
                {
                    switch (id)
                    {
                        /*case 0:
                            if (dataTable[i, carPart].Equals("Bayes"))
                            {
                                //chart.DataSource.AddPointToCategory("Bayes", 2, float.Parse(dataTable[i, 3]));
                                //avg1 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                //count1++;
                                if (dataTable[i, color].Equals("Bayes"))
                                {
                                    chart.DataSource.AddPointToCategory("Bayes", 1, float.Parse(dataTable[i, 3]));
                                    avg1 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    count1++;
                                    //candle.DataSource.AddCandleToCategory("Player 1", new CandleChartData.CandleValue(Random.Range(5f, 10f), Random.Range(10f, 15f), Random.Range(0f, 5f), Random.Range(5f, 10f), i * 10f / 30f, Random.value * 10f / 30f));
                                }
                                if (dataTable[i, color].Equals("Nightingale"))
                                {
                                    chart.DataSource.AddPointToCategory("Nightingale", 2, float.Parse(dataTable[i, 3]));
                                    avg2 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    count2++;
                                }
                                if (dataTable[i, color].Equals("Gauss"))
                                {
                                    chart.DataSource.AddPointToCategory("Gauss", 3, float.Parse(dataTable[i, 3]));
                                    avg3 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    count3++;
                                }
                            }

                            if (dataTable[i, carPart].Equals("Nightingale"))
                            {
                                //chart.DataSource.AddPointToCategory("Nightingale", 5, float.Parse(dataTable[i, 3]));
                                //avg2 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                //count2++;
                                if (dataTable[i, color].Equals("Bayes"))
                                {
                                    chart.DataSource.AddPointToCategory("Bayes", 5, float.Parse(dataTable[i, 3]));
                                    avg4 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    count4++;
                                    //candle.DataSource.AddCandleToCategory("Player 1", new CandleChartData.CandleValue(Random.Range(5f, 10f), Random.Range(10f, 15f), Random.Range(0f, 5f), Random.Range(5f, 10f), i * 10f / 30f, Random.value * 10f / 30f));
                                }
                                if (dataTable[i, color].Equals("Nightingale"))
                                {
                                    chart.DataSource.AddPointToCategory("Nightingale", 6, float.Parse(dataTable[i, 3]));
                                    avg5 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    count5++;
                                }
                                if (dataTable[i, color].Equals("Gauss"))
                                {
                                    chart.DataSource.AddPointToCategory("Gauss", 7, float.Parse(dataTable[i, 3]));
                                    avg6 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    count6++;
                                }
                            }
                            if (dataTable[i, carPart].Equals("Gauss"))
                            {
                                //chart.DataSource.AddPointToCategory("Gauss", 8, float.Parse(dataTable[i, 3]));
                                avg3 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                //count3++;
                                if (dataTable[i, color].Equals("Bayes"))
                                {
                                    chart.DataSource.AddPointToCategory("Bayes", 8, float.Parse(dataTable[i, 3]));
                                    avg7 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    count7++;
                                    //candle.DataSource.AddCandleToCategory("Player 1", new CandleChartData.CandleValue(Random.Range(5f, 10f), Random.Range(10f, 15f), Random.Range(0f, 5f), Random.Range(5f, 10f), i * 10f / 30f, Random.value * 10f / 30f));
                                }
                                if (dataTable[i, color].Equals("Nightingale"))
                                {
                                    chart.DataSource.AddPointToCategory("Nightingale", 9, float.Parse(dataTable[i, 3]));
                                    avg8 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    count8++;
                                }
                                if (dataTable[i, color].Equals("Gauss"))
                                {
                                    chart.DataSource.AddPointToCategory("Gauss", 10, float.Parse(dataTable[i, 3]));
                                    avg9 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    count9++;
                                }
                            }

                            break;*/
                        case 0:
                            if (dataTable[i, 5].ToLower().Equals(PlayerData.Instance.playerId.ToLower())
                                && dataTable[i, 6].ToLower().Equals(PlayerData.Instance.groupId.ToLower()))
                            {
                                if (dataTable[i, carPart].Equals("Bayes"))
                                {
                                    /*chart.DataSource.AddPointToCategory("Bayes", 2, float.Parse(dataTable[i, 3]));
                                    avg1 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    count1++;*/
                                    if (dataTable[i, color].Equals("Bayes"))
                                    {
                                        chart.DataSource.AddPointToCategory("Bayes", 1, float.Parse(dataTable[i, 3]));
                                        avg1 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count1++;
                                        //candle.DataSource.AddCandleToCategory("Player 1", new CandleChartData.CandleValue(Random.Range(5f, 10f), Random.Range(10f, 15f), Random.Range(0f, 5f), Random.Range(5f, 10f), i * 10f / 30f, Random.value * 10f / 30f));
                                    }
                                    if (dataTable[i, color].Equals("Nightingale"))
                                    {
                                        chart.DataSource.AddPointToCategory("Nightingale", 2, float.Parse(dataTable[i, 3]));
                                        avg2 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count2++;
                                    }
                                    if (dataTable[i, color].Equals("Gauss"))
                                    {
                                        chart.DataSource.AddPointToCategory("Gauss", 3, float.Parse(dataTable[i, 3]));
                                        avg3 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count3++;
                                    }
                                }

                                if (dataTable[i, carPart].Equals("Nightingale"))
                                {
                                    /*chart.DataSource.AddPointToCategory("Nightingale", 5, float.Parse(dataTable[i, 3]));
                                    avg2 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    count2++;*/
                                    if (dataTable[i, color].Equals("Bayes"))
                                    {
                                        chart.DataSource.AddPointToCategory("Bayes", 5, float.Parse(dataTable[i, 3]));
                                        avg4 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count4++;
                                        //candle.DataSource.AddCandleToCategory("Player 1", new CandleChartData.CandleValue(Random.Range(5f, 10f), Random.Range(10f, 15f), Random.Range(0f, 5f), Random.Range(5f, 10f), i * 10f / 30f, Random.value * 10f / 30f));
                                    }
                                    if (dataTable[i, color].Equals("Nightingale"))
                                    {
                                        chart.DataSource.AddPointToCategory("Nightingale", 6, float.Parse(dataTable[i, 3]));
                                        avg5 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count5++;
                                    }
                                    if (dataTable[i, color].Equals("Gauss"))
                                    {
                                        chart.DataSource.AddPointToCategory("Gauss", 7, float.Parse(dataTable[i, 3]));
                                        avg6 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count6++;
                                    }
                                }
                                if (dataTable[i, carPart].Equals("Gauss"))
                                {
                                    /*chart.DataSource.AddPointToCategory("Gauss", 8, float.Parse(dataTable[i, 3]));
                                    avg3 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    count3++;*/
                                    if (dataTable[i, color].Equals("Bayes"))
                                    {
                                        chart.DataSource.AddPointToCategory("Bayes", 8, float.Parse(dataTable[i, 3]));
                                        avg7 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count7++;
                                        //candle.DataSource.AddCandleToCategory("Player 1", new CandleChartData.CandleValue(Random.Range(5f, 10f), Random.Range(10f, 15f), Random.Range(0f, 5f), Random.Range(5f, 10f), i * 10f / 30f, Random.value * 10f / 30f));
                                    }
                                    if (dataTable[i, color].Equals("Nightingale"))
                                    {
                                        chart.DataSource.AddPointToCategory("Nightingale", 9, float.Parse(dataTable[i, 3]));
                                        avg8 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count8++;
                                    }
                                    if (dataTable[i, color].Equals("Gauss"))
                                    {
                                        chart.DataSource.AddPointToCategory("Gauss", 10, float.Parse(dataTable[i, 3]));
                                        avg9 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count9++;
                                    }
                                }
                            }

                            break;
                        case 1:
                            if (dataTable[i, 6].ToLower().Equals(PlayerData.Instance.groupId.ToLower()))
                            {
                                if (dataTable[i, carPart].Equals("Bayes"))
                                {
                                    /*chart.DataSource.AddPointToCategory("Bayes", 2, float.Parse(dataTable[i, 3]));
                                    avg1 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    count1++;*/
                                    if (dataTable[i, color].Equals("Bayes"))
                                    {
                                        chart.DataSource.AddPointToCategory("Bayes", 1, float.Parse(dataTable[i, 3]));
                                        avg1 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count1++;
                                        //candle.DataSource.AddCandleToCategory("Player 1", new CandleChartData.CandleValue(Random.Range(5f, 10f), Random.Range(10f, 15f), Random.Range(0f, 5f), Random.Range(5f, 10f), i * 10f / 30f, Random.value * 10f / 30f));
                                    }
                                    if (dataTable[i, color].Equals("Nightingale"))
                                    {
                                        chart.DataSource.AddPointToCategory("Nightingale", 2, float.Parse(dataTable[i, 3]));
                                        avg2 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count2++;
                                    }
                                    if (dataTable[i, color].Equals("Gauss"))
                                    {
                                        chart.DataSource.AddPointToCategory("Gauss", 3, float.Parse(dataTable[i, 3]));
                                        avg3 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count3++;
                                    }
                                }

                                if (dataTable[i, carPart].Equals("Nightingale"))
                                {
                                    /*chart.DataSource.AddPointToCategory("Nightingale", 5, float.Parse(dataTable[i, 3]));
                                    avg2 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    count2++;*/
                                    if (dataTable[i, color].Equals("Bayes"))
                                    {
                                        chart.DataSource.AddPointToCategory("Bayes", 5, float.Parse(dataTable[i, 3]));
                                        avg4 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count4++;
                                        //candle.DataSource.AddCandleToCategory("Player 1", new CandleChartData.CandleValue(Random.Range(5f, 10f), Random.Range(10f, 15f), Random.Range(0f, 5f), Random.Range(5f, 10f), i * 10f / 30f, Random.value * 10f / 30f));
                                    }
                                    if (dataTable[i, color].Equals("Nightingale"))
                                    {
                                        chart.DataSource.AddPointToCategory("Nightingale", 6, float.Parse(dataTable[i, 3]));
                                        avg5 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count5++;
                                    }
                                    if (dataTable[i, color].Equals("Gauss"))
                                    {
                                        chart.DataSource.AddPointToCategory("Gauss", 7, float.Parse(dataTable[i, 3]));
                                        avg6 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count6++;
                                    }
                                }
                                if (dataTable[i, carPart].Equals("Gauss"))
                                {
                                    /*chart.DataSource.AddPointToCategory("Gauss", 8, float.Parse(dataTable[i, 3]));
                                    avg3 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                    count3++;*/
                                    if (dataTable[i, color].Equals("Bayes"))
                                    {
                                        chart.DataSource.AddPointToCategory("Bayes", 9, float.Parse(dataTable[i, 3]));
                                        avg7 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count7++;
                                        //candle.DataSource.AddCandleToCategory("Player 1", new CandleChartData.CandleValue(Random.Range(5f, 10f), Random.Range(10f, 15f), Random.Range(0f, 5f), Random.Range(5f, 10f), i * 10f / 30f, Random.value * 10f / 30f));
                                    }
                                    if (dataTable[i, color].Equals("Nightingale"))
                                    {
                                        chart.DataSource.AddPointToCategory("Nightingale", 10, float.Parse(dataTable[i, 3]));
                                        avg8 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count8++;
                                    }
                                    if (dataTable[i, color].Equals("Gauss"))
                                    {
                                        chart.DataSource.AddPointToCategory("Gauss", 11, float.Parse(dataTable[i, 3]));
                                        avg9 += (int)Mathf.Floor(float.Parse(dataTable[i, 3]));
                                        count9++;
                                    }
                                }
                            }

                            break;
                    }
                }
            }
        }
        chart.DataSource.EndBatch();
        updatedAvg = true;
        UpdateAvg3Variable();

    }

    // Returns 0 if value is not chosen. Returns 1 if everything goes smoothly.
    public void ChangeTrack()
    {



        /*string curTrack = "";

        if (track == 0)
        {
            return;

        }

        track--;
        curTrack = trackArray[track];

        bool ranOnce = false;

        while (!ranOnce)
        {
            chart.DataSource.StartBatch();
            //chart2.DataSource.StartBatch();
            //chart3.DataSource.StartBatch();

            chart.DataSource.ClearCategory("Bayes");
            chart.DataSource.ClearCategory("Nightingale");
            chart.DataSource.ClearCategory("Gauss");

            for (int i = 0; i < dataSize; i++)
            {
                if (float.Parse(dataTable[i, 3]) < 90)
                {
                    if (dataTable[i, 4].Equals(curTrack))
                    {
                        chart.DataSource.AddPointToCategory("Bayes", 1, float.Parse(dataTable[i, 3]));
                        chart.DataSource.AddPointToCategory("Nightingale", 3, float.Parse(dataTable[i, 3]));
                        chart.DataSource.AddPointToCategory("Gauss", 5, float.Parse(dataTable[i, 3]));
                    }
                }

            }

            chart.DataSource.EndBatch();
            //chart2.DataSource.EndBatch();
            //chart3.DataSource.EndBatch();

            ranOnce = true;
        }*/
    }

    void UpdateGraphs()
    {
        while (!inFirst && !inSecond)
        {
            chart.DataSource.StartBatch();
            //chart2.DataSource.StartBatch();
            //chart3.DataSource.StartBatch();

            chart.DataSource.ClearCategory("Bayes");
            //chart2.DataSource.ClearCategory("Nightingale");
            //chart3.DataSource.ClearCategory("Gauss");

            for (int i = 0; i < dataSize; i++)
            {
                if(float.Parse(dataTable[i, 3]) < 90)
                { if (dataTable[i, 1].Equals("Bayes"))
                    {
                        chart.DataSource.AddPointToCategory("Bayes", 2, float.Parse(dataTable[i, 3]));
                        //candle.DataSource.AddCandleToCategory("Player 1", new CandleChartData.CandleValue(Random.Range(5f, 10f), Random.Range(10f, 15f), Random.Range(0f, 5f), Random.Range(5f, 10f), i * 10f / 30f, Random.value * 10f / 30f));

                    }
                    if (dataTable[i, 1].Equals("Nightingale"))
                    {
                        chart.DataSource.AddPointToCategory("Nightingale", 6, float.Parse(dataTable[i, 3]));
                    }
                    if (dataTable[i, 1].Equals("Gauss"))
                    {
                        chart.DataSource.AddPointToCategory("Gauss", 10, float.Parse(dataTable[i, 3]));
                    }
                }

            }

            chart.DataSource.EndBatch();
            //chart2.DataSource.EndBatch();
            //chart3.DataSource.EndBatch();
            inFirst = true;
            inSecond = true;
        }
    }

    IEnumerator GetScores()
    {
        inFirst = true;

        // Web request to get string from DB using PHP script scored at the following URL:
        using (UnityWebRequest getDataFromDB = UnityWebRequest.Get("https://stat2games.sites.grinnell.edu/php/getracerfinishtimedata.php"))
        {
            // Request and wait for the desired page.
            yield return getDataFromDB.SendWebRequest();

            string[] pages = "".Split('/');
            int page = pages.Length - 1;

            if (getDataFromDB.isNetworkError)
            {
                Debug.Log(pages[page] + ": Error: " + getDataFromDB.error);
            }
            else
            {
                // This should be the text
                Debug.Log(pages[page] + ":\nReceived: " + getDataFromDB.downloadHandler.text);
                dataTable = ParseData(getDataFromDB.downloadHandler.text);
            }
        }

        inFirst = false;
    }


    string[,] ParseData(string str)
    {

        string[,] arr = new string[dataSize, 7];
        string[] row = str.Split('\n');
        for (int i = 0; i < dataSize; i++)
        {
            string[] category = row[i].Split(';');
            for (int j = 0; j < 7; j++)
            {
                arr[i, j] = category[j];
            }
        }

        return arr;
    }


    IEnumerator GetSize()
    {
        inSecond = true;

        // Get Number of rows from DB
        string getGameNumURL = "https://stat2games.sites.grinnell.edu/php/getracergamenum.php";

        using (UnityWebRequest getGameNum = UnityWebRequest.Get(getGameNumURL))
        {
            // Request and wait for the desired page.
            yield return getGameNum.SendWebRequest();

            string[] pages = getGameNumURL.Split('/');
            int page = pages.Length - 1;

            if (getGameNum.isNetworkError)
            {
                Debug.Log(pages[page] + ": Error: " + getGameNum.error);
            }
            else
            {

                dataSize = Int32.Parse(getGameNum.downloadHandler.text);
            }
        }

        inSecond = false;

    }



    public void GoBackFromDataVis()
    {
        SceneManager.LoadScene("MainMenu");
    }
}

