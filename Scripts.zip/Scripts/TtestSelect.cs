﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class TtestSelect : MonoBehaviour
{

	public Dropdown car1DropDown;
	public Dropdown car2DropDown;
	public Dropdown trackDropDown;
	public string nextSceneName;

	public GameObject[] selections;

	public int bodyIndex;
	public int engineIndex;
	public int wheelIndex;


	//private int race = 0;

    void Start()
    {
		bodyIndex = -1;
		engineIndex = -1;
		wheelIndex = -1;
		foreach (GameObject obj in selections)
		{
			obj.SetActive(true);
		}
	}

    void Update()
    {
		if (MainMenuController.ttest[0] == 1)
		{
            MainMenuController.ttest[1] = car2DropDown.value;
			MainMenuController.ttest[2] = trackDropDown.value;
			Debug.Log("race is 0");
			LoadCars(car1DropDown.value);
			//race++;
			LoadTrack(trackDropDown.value);
		}
        else 
		{
			//firstrace = false;
			Debug.Log("race is 1");
			foreach (GameObject obj in selections)
			{
				obj.SetActive(false);
			}
			LoadCars(MainMenuController.ttest[1]);
			LoadTrack(MainMenuController.ttest[2]);
			//race = 0;
		}
	}

	public void LoadTrack(int trackindex)
	{
		switch (trackindex)
		{
			case 0:
				{
					nextSceneName = "OvalTrack";
					Debug.Log("selecting oval track");
					break;
				}
			case 1:
				{
					nextSceneName = "StraightTrack";
					Debug.Log("selecting straight track");
					break;
				}

			case 2:
				{
					nextSceneName = "8Track";
					Debug.Log("selecting 8 track");
					break;
				}
			case 3:
				{
					nextSceneName = "ComplexTrack";
					Debug.Log("selecting complex track");
					break;
				}
			case 4:
                {
					nextSceneName = "TutorialTrack";
					Debug.Log("selecting tut track");
					break;
                }
			default:
				{
					break;

				}
		}
	}

	public void LoadCars(int carindex)
	{
		switch (carindex)
		{
			case 1:
				{
					bodyIndex = 0;
					engineIndex = 0;
					wheelIndex = 0;
					Debug.Log("Bayes");
					break;
				}
			case 2:
				{
					bodyIndex = 2;
					engineIndex = 2;
					wheelIndex = 2;
					Debug.Log("Gauss");
					break;
				}
			case 3:
				{
					bodyIndex = 1;
					engineIndex = 1;
					wheelIndex = 1;
					Debug.Log("Nightingale");
					break;
				}
			default:
				{
					bodyIndex = 0;
					engineIndex = 0;
					wheelIndex = 0;
					break;
				};
		}
	}

	public void Next()
	{
			DataManager.Instance.body = bodyIndex;
			DataManager.Instance.engine = engineIndex;
			DataManager.Instance.tire = wheelIndex;
			SceneManager.LoadScene(nextSceneName);
	}

		

		public void Back()
	{
		MainMenuController.ttest[3] = 0;
		SceneManager.LoadScene("MainMenu");
	}
}
