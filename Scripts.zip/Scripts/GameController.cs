﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
using System.Runtime.InteropServices;
using System.Linq;

public class GameController : MonoBehaviour {

	private static GameController _instance;
	public static GameController Instance { get { return _instance; } }

	public Text timer;
	public bool racing;
	public bool timing;
  //  public bool isPaused;

	public GameObject[] endObjects;
	public GameObject[] endObjects2;
	public Text[] endStats;
	//public int trialNum = 0;

	public bool submitted = false;
	public static bool isPaused = false;
	public GameObject pauseMenuUI;

	public float time;
	public float offTrackTime;


	public GameObject mutebutton;
	public GameObject unmutebutton;
	//static bool mute = false;

	// List<string> badWords;
	//[SerializeField] TextAsset badWordsFile;

	// Use this for initialization
	void Awake () {
		if (_instance == null) {
			_instance = this;
		} else if (_instance != this) {
			Destroy (gameObject);
		}
    racing = true;
		time = 0;
		offTrackTime = 0;
	}

	void Start() {
		//AudioListener.volume = 0.2f;
		foreach (GameObject endObject in endObjects) {
			endObject.SetActive (false);
		}
		timing = false;
		AudioListener.volume = PlayerPrefs.GetFloat("volume");
	}

	// Update is called once per frame
	void Update () {
		if (timing) {
			time += Time.deltaTime;
			timer.text = (Math.Truncate ((double)time * 100.0) / 100.0).ToString ();
			if (!CarData.Instance.onTrack) {
				offTrackTime += Time.deltaTime;
			}
			if (Input.GetKeyDown(KeyCode.Escape))
			{
					if (isPaused)
					{
							Resume();
					}
					else
					{
							Pause();
					}
			}

		}
	}

	public void MuteGame()
	{
		//mute = !gameObject.GetComponent<AudioSource>().mute;
		if (!MainMenuController.mute)
		{
			AudioListener.volume = 0f;
			PlayerPrefs.SetFloat("volume", 0.0f);
			MainMenuController.mute = true;
			Debug.Log("mute");
		}
		else
		{
			AudioListener.volume = 0.2f;
			PlayerPrefs.SetFloat("volume", 0.2f);
			MainMenuController.mute = false;
			Debug.Log("unmute");
		}
	}


	public void SetCarSettings(float mass, float drag, float torque, float tireRadius) {
		CarData.Instance.SetCarSettings (mass, drag, torque, tireRadius);
	}

	public void StopTimer() {
		if (racing || timing) {
			timing = false;
			racing = false;
		}
	}


  // Another way to implement pause functionality
/*
    public void Pause()
    {
        if (isPaused == true)
        {
            Time.timeScale = 1;
            isPaused = false;
        }
        else
        {
            Time.timeScale = 0;
            isPaused = true;
        }
    }
		*/

public void Pause()
{
		pauseMenuUI.SetActive(true);
		Time.timeScale = 0f;
		isPaused = true;
		if (SceneManager.GetActiveScene ().name.Equals ("MainMenu"))
		{
			Time.timeScale = 1f;
			isPaused = false;
		}
}

public void Resume()
{
		pauseMenuUI.SetActive(false);
		Time.timeScale = 1f;
		isPaused = false;
}


        public void PassCheckPoint(int n) {
		if (DataManager.Instance.checkPoints [n - 1] == -1.0f) {
			Debug.Log("check time is " + time);
			DataManager.Instance.checkPoints [n - 1] = time;
			Debug.Log("set " + (n-1) + " to " + DataManager.Instance.checkPoints[n - 1]);
		}
	}

	public void SubmitData(bool submit) {
		
			if (!submitted && submit)
			{
				global::SubmitData.Instance.SubmitUpload();
				submitted = true;
				StopTimer();
			}
		if (MainMenuController.tutorial)
		{
			foreach (GameObject endObject in endObjects2)
			{
				endObject.SetActive(true);
			}
		}
		 else if (MainMenuController.ttest[0] == 1)
			{
				endObjects[0].SetActive(true);
				endObjects[3].SetActive(true);
				endObjects[4].SetActive(true);
				endObjects[6].SetActive(true);
				endObjects[1].SetActive(false);
				endObjects[2].SetActive(false);
				endObjects[5].SetActive(false);
			}
			else if (MainMenuController.ttest[3] == 1)
			{
				endObjects[0].SetActive(true);
				endObjects[3].SetActive(true);
				endObjects[4].SetActive(true);
				endObjects[6].SetActive(false);
				endObjects[1].SetActive(true);
				endObjects[2].SetActive(true);
				endObjects[5].SetActive(false);
			}
			else
			{
				foreach (GameObject endObject in endObjects)
				{
					endObject.SetActive(true);
					//endObjects2.SetActive(false);
				}
				endObjects[6].SetActive(false);
			}
			foreach (Text stat in endStats)
			{
				if (stat.name.Equals("Player ID"))
				{
					stat.text = "Player ID: " + PlayerData.Instance.playerId;
				}
				else if (stat.name.Equals("Group ID"))
				{
					stat.text = "Group ID: " + PlayerData.Instance.groupId;
				}
				else if (stat.name.Equals("Body"))
				{
					stat.text = "Body: " + DataManager.Instance.bodyName;
				}
				else if (stat.name.Equals("Engine"))
				{
					stat.text = "Engine: " + DataManager.Instance.engineName;
				}
				else if (stat.name.Equals("Tire"))
				{
					stat.text = "Tire: " + DataManager.Instance.tireName;
				}
				else if (stat.name.Equals("Time"))
				{
					stat.text = "Time: " + (Math.Truncate((double)time * 100.0) / 100.0).ToString();
				}
			}

	}

	public void MainMenu() {
		Time.timeScale = 1f;
		MainMenuController.ttest[3] = 0;
		SceneManager.LoadScene ("MainMenu");
	}

    public void PlayAgain()
    {
			  Time.timeScale = 1f;
		MainMenuController.ttest[3] = 0;
		SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

	public void SecondCar()
	{
		MainMenuController.ttest[0] = 0;
		Time.timeScale = 1f;
		SceneManager.LoadScene("T-test");
	}


	public void OpenDataPage() {
		MainMenuController.ttest[3] = 0;
		string url = "https://www.stat2games.sites.grinnell.edu/data/racer/racer.php";
		OpenLinkJSPlugin(url);
	}



	private void OpenLinkJSPlugin(string url)
	{
#if !UNITY_EDITOR
        openWindow(url);
#endif
	}

	[DllImport("__Internal")]
	private static extern void openWindow(string url);


}
