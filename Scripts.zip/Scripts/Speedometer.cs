﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Speedometer : MonoBehaviour
{
    Text speedText;
    public static int curSpeed;

    // Start is called before the first frame update
    void Start()
    {

        speedText = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {

       speedText.text = Math.Round(CarData.Instance.curSpeed).ToString();
    }
}
