﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections;
using System.Linq;
using UnityEngine.EventSystems;
using System.Runtime.InteropServices;
using TMPro;


public class MainMenuController : MonoBehaviour {

    private static MainMenuController _instance;

    // if ttest is on ttest[0] = 1
    // if ttest[3] = 1, restart button is disabled
    public static int[] ttest = { 0, 0, 0, 0 };
    public static bool tutorial = false;
    public static MainMenuController Instance { get { return _instance; } }

    public InputField playerIDText;
	  public InputField groupIDText;
    public InputField[] optionalVariables;
    public GameObject[] panels; //objects that appear when a player tries to continue without entering IDs
                                // List<string> badWords;
                                //[SerializeField] TextAsset badWordsFile;


    //mute
    public GameObject mutebutton;
    public GameObject unmutebutton;
    public static bool mute = false;
    EventSystem system;

    //credits
    
    public GameObject creditpage;


  
    [SerializeField]
    public TextAsset badWordsFile;

    private string[] badWords;

    [DllImport("__Internal")]
    private static extern void OpenWindow(string url);

    void Awake() {
        if (_instance == null) {
            _instance = this;
        } else if (_instance != this) {
            Destroy(gameObject);
        }

        badWords = badWordsFile.text.Split(',');
    }

    private void Start() {
        creditpage.SetActive(false);
        AudioListener.volume = 0.2f;
        PlayerPrefs.SetFloat("volume", 0.2f);
        //playerIDText.contentType = InputField.ContentType.Custom;
        panels[2].SetActive(false);
        playerIDText.contentType = InputField.ContentType.Alphanumeric;
        if (!string.IsNullOrEmpty(PlayerData.Instance.playerId)) {
            playerIDText.text = PlayerData.Instance.playerId;
        }
        groupIDText.characterLimit = 16;
        groupIDText.contentType = InputField.ContentType.Alphanumeric;
        if (!string.IsNullOrEmpty(PlayerData.Instance.groupId)) {
            groupIDText.text = PlayerData.Instance.groupId;
        }
        system = EventSystem.current;
        //mute = false;
        unmutebutton.SetActive(false);
        
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            Selectable next = system.currentSelectedGameObject.GetComponent<Selectable>().FindSelectableOnDown();

            if (next != null)
            {

                InputField inputfield = next.GetComponent<InputField>();
                if (inputfield != null)
                    inputfield.OnPointerClick(new PointerEventData(system));  //if it's an input field, also set the text caret

                system.SetSelectedGameObject(next.gameObject, new BaseEventData(system));
            }
            //else Debug.Log("next nagivation element not found");


        }

       /* if (mute)
        {
            gameObject.GetComponent<AudioSource>().mute = true;
        } else
        {
            gameObject.GetComponent<AudioSource>().mute = false;
        }*/
    }




    public void MuteGame()
    {
        if (!mute)
        {
            AudioListener.volume = 0f;
            PlayerPrefs.SetFloat("volume", 0.0f);
            mute = true;
            Debug.Log("mute");
        } else {
            AudioListener.volume = 0.2f;
            PlayerPrefs.SetFloat("volume", 0.2f);
            mute = false;
            Debug.Log("unmute");
        }
    }

 

    public void LoadDataVisual()
    {
        tutorial = false;
        PlayerData.Instance.playerId = playerIDText.text;
        PlayerData.Instance.groupId = groupIDText.text;
        SceneManager.LoadScene("Data");
    }

    public void LoadTutorial() {
        //Debug.Log("loading tut");
        if (IsIDsEmpty())
        {
            panels[0].SetActive(true);
            panels[1].SetActive(true);
            panels[2].SetActive(false);
        }
        else if (IsBadWord(playerIDText.text, groupIDText.text) || CheckOptionalVariable(optionalVariables))
        {
            panels[0].SetActive(false);
            panels[1].SetActive(false);
            panels[2].SetActive(true);
        }
        else {
            Debug.Log(playerIDText.text);
            
                SetInputs();
                tutorial = true;
                SceneManager.LoadScene("TutorialInstructions");

        }
	}

    public void LoadTtest()
    {
        if (IsIDsEmpty())
        {
            panels[0].SetActive(true);
            panels[1].SetActive(true);
            panels[2].SetActive(false);
        }
        else if (IsBadWord(playerIDText.text, groupIDText.text) || CheckOptionalVariable(optionalVariables))
        {
            panels[0].SetActive(false);
            panels[1].SetActive(false);
            panels[2].SetActive(true);
        }
        else
        {
            SetInputs();
            ttest[0] = 1;
            ttest[3] = 1;
            tutorial = false;
            Debug.Log("setting for ttest");
            SceneManager.LoadScene("T-test");
        }
    }

    public void LoadMainMenu() {
		SceneManager.LoadScene("MainMenu");
	}

	public void LoadCarSelect() {
        if (IsIDsEmpty())
        {
            panels[0].SetActive(true);
            panels[1].SetActive(true);
            panels[2].SetActive(false);
        }
        else if (IsBadWord(playerIDText.text, groupIDText.text) || CheckOptionalVariable(optionalVariables))
        {
            panels[0].SetActive(false);
            panels[1].SetActive(false);
            panels[2].SetActive(true);
        }
        else {
            tutorial = false;
            SetInputs();
            SceneManager.LoadScene("CarSelect");
        }
    }

	public void LoadPartsSelect() {
        if (IsIDsEmpty())
        {
            panels[0].SetActive(true);
            panels[1].SetActive(true);
            panels[2].SetActive(false);
        }
        else if (IsBadWord(playerIDText.text, groupIDText.text) || CheckOptionalVariable(optionalVariables))
        {
            panels[0].SetActive(false);
            panels[1].SetActive(false);
            panels[2].SetActive(true);
        }
        else
        {
            tutorial = false;
            SetInputs();
            SceneManager.LoadScene("PartsSelect");
        }
	}



	public void OpenDataPage() {
        tutorial = false;
        string url = "https://www.stat2games.sites.grinnell.edu/data/racer/racer.php";
 OpenLinkJSPlugin(url);

    }


    private void OpenLinkJSPlugin(string url)
    {
#if !UNITY_EDITOR
        openWindow(url);
#endif
    }

    [DllImport("__Internal")]
    private static extern void openWindow(string url);



    public void SetInputs() {
            PlayerData.Instance.playerId = playerIDText.text;
            PlayerData.Instance.groupId = groupIDText.text;
            PlayerData.Instance.variable1 = optionalVariables[0].text;
            PlayerData.Instance.variable2 = optionalVariables[1].text;
            PlayerData.Instance.variable3 = optionalVariables[2].text;
    }

    public bool IsIDsEmpty() {
        //Debug.Log("is ids empty");
        return (string.IsNullOrEmpty(groupIDText.text) || string.IsNullOrEmpty(playerIDText.text));
    }

    public void SetLevel(int level) {
		    PlayerData.Instance.level = level;
    }


    public string GetLevel() {
        switch (PlayerData.Instance.level) {
            case 1:
                return "Tutorial";
            case 2:
                return "ChooseCar";
            case 3:
                return "CreateCar";
            case 4:
                return "Paired";
            default:
                return "";
        }
    }

    public void ShowCredit()
    {
        creditpage.SetActive(true);

    }

    public void CloseCredit()
    {
        creditpage.SetActive(false);
    }

    private bool CheckOptionalVariable(InputField[] inputs)
    {
        for (int i = 0; i < 3; i++)
        {
            string str = inputs[i].text;
            if (IsBadWord(str, ""))
            {
                return true;
            }
        }
        return false;
    }


    private bool IsBadWord(string player, string group)
    {
        //Debug.Log("bad word check " + word);
        player = player.ToLower();
        group = group.ToLower();
        

        
        foreach (string badword in badWords)
        {
            string newbadword = badword.Substring(1);
     
            if (player.Contains(newbadword))
            {
                //Debug.Log(word + " is a bad word");
                return true;
            }
            if (group.Contains(newbadword))
            {
                return true;
            }
        }

        //Debug.Log(word + " is not a bad word");
        return false;
    }
}
